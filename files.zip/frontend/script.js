document.getElementById('checkHealth').addEventListener('click', async () => {
  const statusDiv = document.getElementById('healthStatus');
  statusDiv.textContent = 'Checando...';
  try {
    const res = await fetch('/api/health');
    const data = await res.json();
    statusDiv.textContent = `Status da API: ${data.status}`;
  } catch (e) {
    statusDiv.textContent = 'Erro ao conectar com a API';
  }
});